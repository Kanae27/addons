<?php
// Start session to access session variables
session_start();

// Include database connection
require_once '../includes/db_connection.php';

// Set up error handling for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Function to log errors
function logError($message) {
    error_log("[Image Upload Error] " . $message);
}

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Check if files were uploaded
if (!isset($_FILES['images']) || empty($_FILES['images']['name'][0])) {
    echo json_encode(['success' => false, 'message' => 'No images uploaded']);
    exit;
}

// Get narrative ID from the request
$narrativeId = isset($_POST['narrative_id']) ? intval($_POST['narrative_id']) : 0;
$campus = isset($_POST['campus']) ? $_POST['campus'] : '';

// Create upload directory if it doesn't exist
$uploadDir = '../photos/';
if (!file_exists($uploadDir)) {
    if (!mkdir($uploadDir, 0755, true)) {
        echo json_encode(['success' => false, 'message' => 'Failed to create upload directory']);
        exit;
    }
}

// Process uploaded files
$uploadedImages = [];
$errors = [];
$timestamp = time(); // Use timestamp to make filenames unique

// Create a temporary session key to track this upload batch
$uploadBatchKey = 'upload_batch_' . $timestamp;
$_SESSION[$uploadBatchKey] = [];

// Process each uploaded file
foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
    // Check if the file was uploaded successfully
    if ($_FILES['images']['error'][$key] !== UPLOAD_ERR_OK) {
        $errors[] = "Error uploading file: " . $_FILES['images']['name'][$key];
        continue;
    }
    
    // Generate a unique filename
    $filename = 'narrative_' . $timestamp . '_' . $key . '.jpeg';
    $targetPath = $uploadDir . $filename;
    
    // Check file type
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/jpg'];
    if (!in_array($_FILES['images']['type'][$key], $allowedTypes)) {
        $errors[] = "Invalid file type: " . $_FILES['images']['name'][$key];
        continue;
    }
    
    // Check file size (limit to 5MB)
    if ($_FILES['images']['size'][$key] > 5 * 1024 * 1024) {
        $errors[] = "File too large: " . $_FILES['images']['name'][$key];
        continue;
    }
    
    // Move the uploaded file to the target path
    if (move_uploaded_file($tmp_name, $targetPath)) {
        $uploadedImages[] = $filename;
        
        // Store in session for this batch
        $_SESSION[$uploadBatchKey][] = $filename;
    } else {
        $errors[] = "Failed to move uploaded file: " . $_FILES['images']['name'][$key];
    }
}

// If no images were uploaded successfully, return an error
if (empty($uploadedImages)) {
    echo json_encode([
        'success' => false, 
        'message' => 'No images were uploaded successfully', 
        'errors' => $errors
    ]);
    exit;
}

// If we have a narrative ID, update the database entry with the new images
if ($narrativeId > 0) {
    try {
        // First get the existing photo paths
        $stmt = $conn->prepare("SELECT photo_path, photo_paths FROM narrative_entries WHERE id = ?");
        $stmt->bind_param("i", $narrativeId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($row = $result->fetch_assoc()) {
            $existingPath = $row['photo_path'];
            $existingPaths = $row['photo_paths'] ? json_decode($row['photo_paths'], true) : [];
            
            // If not an array, initialize as empty array
            if (!is_array($existingPaths)) {
                $existingPaths = [];
            }
            
            // Add the existing path if it's not already in the array
            if ($existingPath && !in_array($existingPath, $existingPaths)) {
                $existingPaths[] = $existingPath;
            }
            
            // Add new paths, avoiding duplicates
            foreach ($uploadedImages as $newPath) {
                if (!in_array($newPath, $existingPaths)) {
                    $existingPaths[] = $newPath;
                }
            }
            
            // Update the database with the new paths
            $photoPathsJson = json_encode($existingPaths);
            $mainPhotoPath = $existingPaths[0] ?? ''; // Use the first image as the main photo
            
            $stmt = $conn->prepare("UPDATE narrative_entries SET photo_path = ?, photo_paths = ? WHERE id = ?");
            $stmt->bind_param("ssi", $mainPhotoPath, $photoPathsJson, $narrativeId);
            $stmt->execute();
            
            // Return success with the complete list of paths
            echo json_encode([
                'success' => true, 
                'message' => 'Images uploaded successfully', 
                'images' => $existingPaths,
                'image_count' => count($existingPaths),
                'narrative_id' => $narrativeId
            ]);
            exit;
        } else {
            // Narrative not found
            echo json_encode([
                'success' => false, 
                'message' => 'Narrative not found', 
                'narrative_id' => $narrativeId
            ]);
            exit;
        }
    } catch (Exception $e) {
        logError("Database error: " . $e->getMessage());
        echo json_encode([
            'success' => false, 
            'message' => 'Database error: ' . $e->getMessage(),
            'narrative_id' => $narrativeId
        ]);
        exit;
    }
} else {
    // For new narratives (no ID yet), just store the paths in the session
    // We'll use a unique session key to track uploads for this form
    if (!isset($_SESSION['temp_narrative_uploads'])) {
        $_SESSION['temp_narrative_uploads'] = [];
    }
    
    // Store the current batch
    $_SESSION['temp_narrative_uploads'] = $uploadedImages;
    
    // Return success with the session paths
    echo json_encode([
        'success' => true, 
        'message' => 'Images uploaded successfully', 
        'images' => $uploadedImages,
        'image_count' => count($uploadedImages),
        'narrative_id' => 0
    ]);
    exit;
}
?> 