<?php
// Start session to access session variables
session_start();

// Include database connection
require_once '../includes/db_connection.php';

// Set up error handling for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Function to log errors
function logError($message) {
    error_log("[Image Remove Error] " . $message);
}

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get parameters
$narrativeId = isset($_POST['narrative_id']) ? intval($_POST['narrative_id']) : 0;
$imagePath = isset($_POST['image_path']) ? $_POST['image_path'] : '';

// Validate parameters
if ($narrativeId <= 0 || empty($imagePath)) {
    echo json_encode(['success' => false, 'message' => 'Invalid parameters']);
    exit;
}

try {
    // First get the existing photo paths
    $stmt = $conn->prepare("SELECT photo_path, photo_paths FROM narrative_entries WHERE id = ?");
    $stmt->bind_param("i", $narrativeId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        $existingPath = $row['photo_path'];
        $existingPaths = $row['photo_paths'] ? json_decode($row['photo_paths'], true) : [];
        
        // If not an array, initialize as empty array
        if (!is_array($existingPaths)) {
            $existingPaths = [];
        }
        
        // Add the existing path if it's not already in the array
        if ($existingPath && !in_array($existingPath, $existingPaths)) {
            $existingPaths[] = $existingPath;
        }
        
        // Check if the image exists in the array
        $imageIndex = array_search($imagePath, $existingPaths);
        if ($imageIndex !== false) {
            // Remove the image from the array
            array_splice($existingPaths, $imageIndex, 1);
            
            // Update the database with the new paths
            $photoPathsJson = json_encode($existingPaths);
            $mainPhotoPath = !empty($existingPaths) ? $existingPaths[0] : '';
            
            $stmt = $conn->prepare("UPDATE narrative_entries SET photo_path = ?, photo_paths = ? WHERE id = ?");
            $stmt->bind_param("ssi", $mainPhotoPath, $photoPathsJson, $narrativeId);
            
            if ($stmt->execute()) {
                // Try to delete the physical file
                $filePath = '../photos/' . $imagePath;
                if (file_exists($filePath)) {
                    if (unlink($filePath)) {
                        logError("File deleted: $filePath");
                    } else {
                        logError("Failed to delete file: $filePath");
                    }
                } else {
                    logError("File not found: $filePath");
                }
                
                // Return success with the updated list of paths
                echo json_encode([
                    'success' => true, 
                    'message' => 'Image removed successfully', 
                    'images' => $existingPaths,
                    'image_count' => count($existingPaths)
                ]);
                exit;
            } else {
                echo json_encode([
                    'success' => false, 
                    'message' => 'Failed to update database: ' . $stmt->error
                ]);
                exit;
            }
        } else {
            echo json_encode([
                'success' => false, 
                'message' => 'Image not found in narrative'
            ]);
            exit;
        }
    } else {
        echo json_encode([
            'success' => false, 
            'message' => 'Narrative not found'
        ]);
        exit;
    }
} catch (Exception $e) {
    logError("Error: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'Error: ' . $e->getMessage()
    ]);
    exit;
}
?> 