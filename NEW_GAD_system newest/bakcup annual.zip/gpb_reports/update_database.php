<?php
// Direct database update script - creates columns needed for the report

// Database connection
$host = 'localhost';
$dbname = 'gad_db';
$username = 'root';
$password = '';

try {
    // Connect to database
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected to database successfully!\n";
    
    // Check if columns exist then add them if they don't
    // This approach is compatible with older MySQL versions
    
    // Function to check if a column exists
    function columnExists($pdo, $table, $column) {
        $stmt = $pdo->prepare("SHOW COLUMNS FROM {$table} LIKE ?");
        $stmt->execute([$column]);
        return $stmt->rowCount() > 0;
    }
    
    // Add actual_male_participants if it doesn't exist
    if (!columnExists($pdo, 'gpb_entries', 'actual_male_participants')) {
        $pdo->exec("ALTER TABLE gpb_entries ADD COLUMN actual_male_participants INT DEFAULT NULL AFTER male_participants");
        echo "Added actual_male_participants column\n";
    } else {
        echo "Column actual_male_participants already exists\n";
    }
    
    // Add actual_female_participants if it doesn't exist
    if (!columnExists($pdo, 'gpb_entries', 'actual_female_participants')) {
        $pdo->exec("ALTER TABLE gpb_entries ADD COLUMN actual_female_participants INT DEFAULT NULL AFTER female_participants");
        echo "Added actual_female_participants column\n";
    } else {
        echo "Column actual_female_participants already exists\n";
    }
    
    // Add actual_cost if it doesn't exist
    if (!columnExists($pdo, 'gpb_entries', 'actual_cost')) {
        $pdo->exec("ALTER TABLE gpb_entries ADD COLUMN actual_cost DECIMAL(10,2) DEFAULT NULL AFTER gad_budget");
        echo "Added actual_cost column\n";
    } else {
        echo "Column actual_cost already exists\n";
    }
    
    // Verify columns exist
    $stmt = $pdo->query("SHOW COLUMNS FROM gpb_entries");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "\nColumns in gpb_entries table:\n";
    foreach ($columns as $column) {
        echo "- $column\n";
    }
    
    // Check if our new columns exist
    $requiredColumns = ['actual_male_participants', 'actual_female_participants', 'actual_cost'];
    $missingColumns = array_diff($requiredColumns, $columns);
    
    if (empty($missingColumns)) {
        echo "\nAll required columns are present!\n";
    } else {
        echo "\nMissing columns: " . implode(', ', $missingColumns) . "\n";
    }
    
} catch (PDOException $e) {
    echo "Database Error: " . $e->getMessage() . "\n";
} 