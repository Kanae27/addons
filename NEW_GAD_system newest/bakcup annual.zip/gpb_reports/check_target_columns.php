<?php
// Check just our target columns
require_once 'config.php';

try {
    $targetColumns = ['actual_male_participants', 'actual_female_participants', 'actual_cost'];
    
    echo "Checking for required columns in gpb_entries table:\n";
    
    foreach ($targetColumns as $column) {
        $stmt = $pdo->prepare("
            SELECT COLUMN_NAME 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = ? 
            AND TABLE_NAME = ? 
            AND COLUMN_NAME = ?
        ");
        $stmt->execute([DB_NAME, 'gpb_entries', $column]);
        $exists = $stmt->rowCount() > 0;
        
        echo "- Column '$column': " . ($exists ? "EXISTS" : "MISSING") . "\n";
        
        // If missing, add it
        if (!$exists) {
            try {
                if ($column == 'actual_male_participants') {
                    $pdo->exec("ALTER TABLE gpb_entries ADD COLUMN actual_male_participants INT DEFAULT NULL AFTER male_participants");
                    echo "  -> Added '$column' column\n";
                } else if ($column == 'actual_female_participants') {
                    $pdo->exec("ALTER TABLE gpb_entries ADD COLUMN actual_female_participants INT DEFAULT NULL AFTER female_participants");
                    echo "  -> Added '$column' column\n";
                } else if ($column == 'actual_cost') {
                    $pdo->exec("ALTER TABLE gpb_entries ADD COLUMN actual_cost DECIMAL(10,2) DEFAULT NULL AFTER gad_budget");
                    echo "  -> Added '$column' column\n";
                }
            } catch (PDOException $e) {
                echo "  -> Failed to add column: " . $e->getMessage() . "\n";
            }
        }
    }
    
    // Show all columns to confirm
    $stmt = $pdo->query("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '" . DB_NAME . "' AND TABLE_NAME = 'gpb_entries' ORDER BY ORDINAL_POSITION");
    $allColumns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "\nAll columns in gpb_entries table:\n";
    foreach ($allColumns as $column) {
        echo "- $column\n";
    }
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
} 