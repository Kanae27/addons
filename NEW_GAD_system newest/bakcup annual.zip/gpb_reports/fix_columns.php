<?php
// Direct SQL implementation to add the necessary columns

// Database credentials - directly included for immediate use
$host = 'localhost';
$dbname = 'gad_db';
$username = 'root';
$password = '';

echo "<h2>Database Column Fix</h2>";
echo "<pre>";

try {
    // Connect to database
    $mysqli = new mysqli($host, $username, $password, $dbname);
    
    // Check connection
    if ($mysqli->connect_error) {
        throw new Exception("Connection failed: " . $mysqli->connect_error);
    }
    
    echo "Connected to database successfully!\n\n";
    
    // Get all current columns
    $result = $mysqli->query("DESCRIBE gpb_entries");
    
    echo "Current columns in gpb_entries table:\n";
    $columns = [];
    while ($row = $result->fetch_assoc()) {
        $columns[] = $row['Field'];
        echo "- " . $row['Field'] . "\n";
    }
    
    echo "\nChecking for required columns...\n";
    
    // Check and add columns
    $needed = [
        'actual_male_participants' => "ALTER TABLE gpb_entries ADD COLUMN actual_male_participants INT DEFAULT NULL AFTER male_participants",
        'actual_female_participants' => "ALTER TABLE gpb_entries ADD COLUMN actual_female_participants INT DEFAULT NULL AFTER female_participants",
        'actual_cost' => "ALTER TABLE gpb_entries ADD COLUMN actual_cost DECIMAL(10,2) DEFAULT NULL AFTER gad_budget"
    ];
    
    $addedColumns = 0;
    
    foreach ($needed as $column => $sql) {
        if (!in_array($column, $columns)) {
            echo "- Adding missing column: $column\n";
            
            if ($mysqli->query($sql)) {
                echo "  -> Success!\n";
                $addedColumns++;
            } else {
                echo "  -> Error: " . $mysqli->error . "\n";
            }
        } else {
            echo "- Column $column already exists\n";
        }
    }
    
    // Show final status
    echo "\nAdded $addedColumns columns\n";
    
    if ($addedColumns > 0) {
        // Get all current columns again
        $result = $mysqli->query("DESCRIBE gpb_entries");
        
        echo "\nUpdated columns in gpb_entries table:\n";
        while ($row = $result->fetch_assoc()) {
            echo "- " . $row['Field'] . "\n";
        }
    }
    
    $mysqli->close();
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}

echo "</pre>";
echo "<p>Return to <a href='gbp_reports.php'>GPB Reports</a></p>";
?> 