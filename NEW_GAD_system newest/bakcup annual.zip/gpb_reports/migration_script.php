<?php
// Database migration script to add actual results columns to gpb_entries table
// Run this script once to update your database schema

// Database connection 
require_once 'config.php';

// Check database connection
try {
    // Use PDO connection from config.php
    echo "Database connection successful!\n";
    
    // Check if the columns already exist
    $checkColumns = [
        'actual_male_participants' => false,
        'actual_female_participants' => false,
        'actual_cost' => false
    ];
    
    // Get existing columns
    $columnsQuery = "SHOW COLUMNS FROM gpb_entries";
    $columnsStmt = $pdo->prepare($columnsQuery);
    $columnsStmt->execute();
    $columns = $columnsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Check which columns exist
    foreach ($columns as $column) {
        if (isset($checkColumns[$column['Field']])) {
            $checkColumns[$column['Field']] = true;
        }
    }
    
    // Add missing columns
    $queriesRun = 0;
    
    if (!$checkColumns['actual_male_participants']) {
        $query = "ALTER TABLE gpb_entries ADD COLUMN actual_male_participants INT DEFAULT NULL AFTER male_participants";
        $stmt = $pdo->prepare($query);
        $stmt->execute();
        echo "Added actual_male_participants column\n";
        $queriesRun++;
    }
    
    if (!$checkColumns['actual_female_participants']) {
        $query = "ALTER TABLE gpb_entries ADD COLUMN actual_female_participants INT DEFAULT NULL AFTER female_participants";
        $stmt = $pdo->prepare($query);
        $stmt->execute();
        echo "Added actual_female_participants column\n";
        $queriesRun++;
    }
    
    if (!$checkColumns['actual_cost']) {
        $query = "ALTER TABLE gpb_entries ADD COLUMN actual_cost DECIMAL(10,2) DEFAULT NULL AFTER gad_budget";
        $stmt = $pdo->prepare($query);
        $stmt->execute();
        echo "Added actual_cost column\n";
        $queriesRun++;
    }
    
    if ($queriesRun === 0) {
        echo "All required columns already exist. No changes made.\n";
    } else {
        echo "Database migration completed successfully. Added $queriesRun column(s).\n";
    }
    
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

echo "Migration script completed.\n"; 