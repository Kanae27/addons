<?php
// Simple script to check database columns
require_once 'config.php';

try {
    // Check columns in gpb_entries table
    $query = "SHOW COLUMNS FROM gpb_entries";
    $stmt = $pdo->prepare($query);
    $stmt->execute();
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Columns in gpb_entries table:\n";
    foreach ($columns as $column) {
        echo "- " . $column['Field'] . "\n";
    }
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
} 